package textpack;

public class textexmp {

	public static void main(String[] args)
	{
	textexmp te1=new textexmp();
	textexmp te2=new textexmp();
	int m1=te1.hashCode();
	int m2=te2.hashCode();
	System.out.println("Hash code of te1  is:"+m1);
	System.out.println("Hash code of te2  is:"+m2);
	if(te1.equals(te2))
	{
		System.out.println("OBJECT ARE EQUALS");
	}
	else
	{
		System.out.println("OBJECT ARE NOT EQUALS");
	}
	}
}

