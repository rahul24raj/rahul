package com.niit.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Cart;
import com.niit.model.Category;
@EnableTransactionManagement
//connects to DB by taking attributes from POJO class
@Repository("cartDAO")
public class CartDAOImpl implements CartDAO
{  //IT WILL CREATE AN OBJECT WITHOUT HELP OF NEW OPERATOER
	@Autowired
	private SessionFactory sessionfactory;
	
	public CartDAOImpl(SessionFactory sessionfactory)
	{
		this.sessionfactory=sessionfactory;
	}
	//used to transaction from model to dao class
	@Transactional
	public void addCart(Cart cart)
	{
		sessionfactory.getCurrentSession().saveOrUpdate(cart);
	}
	@Transactional
	public void deleteCart(int id)
	{
		Cart cart =new Cart();
		cart.setId(id);
		sessionfactory.getCurrentSession().delete(cart);
	}
	@SuppressWarnings("deprecation")
	@Transactional
	public Cart getCart(String proid)
	{
		String hql= "from Cart where user_Id = " +"'" + proid +"'";
		Query query = sessionfactory.getCurrentSession().createQuery(hql);
		List<Cart> listCart= (List<Cart>)query.list();
		if (listCart != null && !listCart.isEmpty())
		{
			return listCart.get(0);
		}
		return  null;
	}
	@Transactional
	public List<Cart> list()
	{
		List<Cart> listCart = (List<Cart>)sessionfactory.getCurrentSession().createCriteria(Cart.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
	     return listCart;
	}
	 @Transactional
	   public List<Cart> userCartList(String uname)
	   {
		   String hql="from Cart where user_Id="+"'"+uname+"'";
		@SuppressWarnings("rawtypes")
		Query query=sessionfactory.getCurrentSession().createQuery(hql);
		@SuppressWarnings("unchecked")
		List<Cart> list = query.list();
		if(list!=null&& !list.isEmpty())
		{
			return list;
		}
		
		return null;
	   }
	
	
	
	
	
	
	
}