package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.dao.ProductDAO;
import com.niit.model.Product;

//testing for product//

public class ProductText {

	public static void main(String[] args) 
	{
	
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		ProductDAO productDAO=(ProductDAO) context.getBean("productDAO");
		System.out.println("success");
		Product product=(Product) context.getBean("product");
		
		product.setId("14");
		product.setName("car");
		product.setPrice(400000);
		product.setDescription("datsun");
		
         productDAO.addProduct(product);
		
	}

}
