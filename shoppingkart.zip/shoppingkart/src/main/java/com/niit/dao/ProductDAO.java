package com.niit.dao;


import com.niit.model.Product;

public interface ProductDAO
{
	public void addProduct1(Product product);

	void addProduct(Product product);
}
