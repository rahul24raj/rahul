package com.niit.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.Category;
import com.niit.model.Product;

@EnableTransactionManagement
@Repository("productDAO")
public class ProductDAOImp implements ProductDAO
{
	@Autowired
 private SessionFactory sessionFactory;
	
	private ProductDAOImp(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	
	@Transactional
	public void addProduct(Product product)
	{
		sessionFactory.getCurrentSession().saveOrUpdate(product);
	}

	@Override
	public void addProduct1(Product product) {
	
	}
		
	
}
