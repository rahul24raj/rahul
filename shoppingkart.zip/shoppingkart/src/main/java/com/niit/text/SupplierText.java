package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


import com.niit.dao.SupplierDAO;

import com.niit.model.Supplier;

public class SupplierText {

	public static void main(String[] args) 
	{
		
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		SupplierDAO supplierDAO=(SupplierDAO) context.getBean("supplierDAO");
		System.out.println("success");
		Supplier supplier=(Supplier) context.getBean("supplier");
		
		supplier.setId("22");
		supplier.setName("bineesh");
		supplier.setAddress("mvm");
		supplier.setPhone("7885");
		
		
		supplierDAO.addSupplier(supplier);
		
	}
		

}
