package com.niit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Entity 
@Table(name="User")
@Component
 public class User
{
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private int id;
       
	   @NotEmpty(message="please enter name")
       private String name;
       
       @NotEmpty(message="please enter address")
       private String address;
       
       @NotEmpty(message="enter email")
       private String email;
       
       @NotEmpty(message="enter phone")
       private String phone;
       
       @NotEmpty(message="enter password")
       private String password;
	
       public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
