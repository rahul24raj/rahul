package filePack;

import java.io.FileOutputStream;

public class FIleExmp {
	
	public void createFile() throws Exception
	{
String name="H1 praveen...";
FileOutputStream fout=new FileOutputStream("hello.xls");
byte b[]=name.getBytes();
fout.write(b);
System.out.println("success...");
	}
	public static void main(String[]args)throws Exception
	{
		FIleExmp fe=new FIleExmp();
		fe.createFile();
	}
	
}
