package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CartDAO;
import com.niit.model.Cart;



public class CartTest
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CartDAO cartDAO=(CartDAO) context.getBean("cartDAO");
		System.out.println("success");
		Cart cart=(Cart) context.getBean("cart");
		
		
		cart.setProduct_Id("w0025");
		cart.setPrice(30000);
		cart.setQuantity(3);
		cart.setStatus("stock");
		cart.setUser_Id(0034);
		
		cartDAO.addCart(cart);
		
		
		
	}
}
