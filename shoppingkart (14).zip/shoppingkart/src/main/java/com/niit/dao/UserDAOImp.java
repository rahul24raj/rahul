package com.niit.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.annotation.Transactional;

import com.niit.model.User;

@EnableTransactionManagement
//connects to DB by taking attribute from pojo class
@Repository("userDAO")
public class UserDAOImp implements UserDAO
{
	//IT WILL CREATE AN OBJECT WITHOUT HELP OF NEW OPERATOR
	@Autowired
	private SessionFactory sessionFactory;
	
	private UserDAOImp(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
	//used to transcation from model to dao class
	@Transactional
	public void addUser(User user)
	{
		sessionFactory.getCurrentSession().save(user);
	}
}
