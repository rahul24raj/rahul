package com.niit.text;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.dao.CategoryDAO;
import com.niit.model.Category;

//testing for category//

public class CategoryText
{
	public static void main(String[] args) 
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		CategoryDAO categoryDAO=(CategoryDAO) context.getBean("categoryDAO");
		System.out.println("success");
		Category category=(Category) context.getBean("category");
		
		category.setId("arun01");
		category.setName("ARUN");
		category.setDescription("8451225");
		
		categoryDAO.addCategory(category);
		
		
		
	}
}