package mapObj;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mapObj.Product;

/**
 * Servlet implementation class MyController
 */
@WebServlet("/MyController")
public class myController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public myController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("pid");
		int id1 = Integer.parseInt(id);
		
		String name = request.getParameter("pname");
		
		String pr = request.getParameter("price");
		int pr1 = Integer.parseInt(pr);
		
		String de = request.getParameter("pdes");
		
		Product p = new Product(id1,name,pr1,de);
		
		ProductDAOimp pd = new ProductDAOimp();
		String msg = pd.addProduct(p);
		
		RequestDispatcher rd = request.getRequestDispatcher("view.jsp");
		request.setAttribute("msg1", msg);
		rd.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
